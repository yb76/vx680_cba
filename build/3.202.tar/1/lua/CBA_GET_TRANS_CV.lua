function get_trans_cv(trk2_pan)
	  txn.fullpan,txn.cv1,txn.cv2,txn.cv3,txn.cv4,txn.cv5 = get_trans_cv2(trk2_pan)
end
