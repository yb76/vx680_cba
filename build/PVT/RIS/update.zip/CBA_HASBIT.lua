function hasbit(x, p)
  return x % (p + p) >= p       
end
