function itaxi_get_print()
  return taxicfg.header,taxicfg.mtrailer,taxicfg.ctrailer
end
